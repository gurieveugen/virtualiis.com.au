<?php
// Registers the new post type 

function beuh_pricingtable_posttype() {
	register_post_type( 'pricing-table',
		array(
			'labels' => array(
				'name' => __( 'Pricing Table', 'beuh_plg' ),
				'singular_name' => __( 'Pricing Table' , 'beuh_plg'),
				'add_new' => __( 'Add New Pricing Table', 'beuh_plg' ),
				'add_new_item' => __( 'Add New Pricing Table', 'beuh_plg' ),
				'edit_item' => __( 'Edit Pricing Table', 'beuh_plg' ),
				'new_item' => __( 'Add New Pricing Table', 'beuh_plg' ),
				'view_item' => __( 'View Pricing Table', 'beuh_plg' ),
				'search_items' => __( 'Search Pricing Table', 'beuh_plg' ),
				'not_found' => __( 'No Pricing Table found', 'beuh_plg' ),
				'not_found_in_trash' => __( 'No Pricing Table found in trash', 'beuh_plg' )
			),
			'public' => true,
			'supports' => array( 'title', 'editor', 'thumbnail','excerpt'),
			'capability_type' => 'post',
			'rewrite' => array("slug" => "pricing-table"), // Permalinks format
			'menu_position' => 5,
			'exclude_from_search' => true 
		)
	);

}

add_action( 'init', 'beuh_pricingtable_posttype' );


