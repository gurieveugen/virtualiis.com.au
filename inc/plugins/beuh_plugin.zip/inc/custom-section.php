<?php
// Registers the new post type 

function csection_posttype() {
	register_post_type( 'custom-section',
		array(
			'labels' => array(
				'name' => __( 'Custom Section', 'beuh_plg' ),
				'singular_name' => __( 'Custom Section' , 'beuh_plg'),
				'add_new' => __( 'Add New Custom Section', 'beuh_plg' ),
				'add_new_item' => __( 'Add New Custom Section', 'beuh_plg' ),
				'edit_item' => __( 'Edit Custom Section', 'beuh_plg' ),
				'new_item' => __( 'Add New Custom Section', 'beuh_plg' ),
				'view_item' => __( 'View Custom Section', 'beuh_plg' ),
				'search_items' => __( 'Search Custom Section', 'beuh_plg' ),
				'not_found' => __( 'No Custom Section found', 'beuh_plg' ),
				'not_found_in_trash' => __( 'No Custom Section found in trash', 'beuh_plg' )
			),
			'public' => true,
			'supports' => array( 'title', 'editor', 'thumbnail','excerpt'),
			'capability_type' => 'post',
			'rewrite' => array("slug" => "custom-section"), // Permalinks format
			'menu_position' => 5,
			'exclude_from_search' => true 
		)
	);

}

add_action( 'init', 'csection_posttype' );


