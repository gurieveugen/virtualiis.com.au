<?php
// Registers the new post type 

function wpt_portfolio_posttype() {
	register_post_type( 'portfolio',
		array(
			'labels' => array(
				'name' => __( 'Portfolio', 'beuh_plg' ),
				'singular_name' => __( 'Portfolio' , 'beuh_plg'),
				'add_new' => __( 'Add New Portfolio', 'beuh_plg' ),
				'add_new_item' => __( 'Add New Portfolio', 'beuh_plg' ),
				'edit_item' => __( 'Edit Portfolio', 'beuh_plg' ),
				'new_item' => __( 'Add New Portfolio', 'beuh_plg' ),
				'view_item' => __( 'View Portfolio', 'beuh_plg' ),
				'search_items' => __( 'Search Portfolio', 'beuh_plg' ),
				'not_found' => __( 'No Portfolio found', 'beuh_plg' ),
				'not_found_in_trash' => __( 'No Portfolio found in trash', 'beuh_plg' )
			),
			'public' => true,
			'supports' => array( 'title', 'editor', 'thumbnail', 'comments' , 'excerpt'),
			'capability_type' => 'post',
			'rewrite' => array("slug" => "portfolio"), // Permalinks format
			'menu_position' => 5,
			'exclude_from_search' => true 
		)
	);

}

add_action( 'init', 'wpt_portfolio_posttype' );

//add taxonomies(portfolio category)
function beuh_taxonomies_portfolio() {
	$labels = array(
		'name'              => _x( 'Portfolio Categories', 'taxonomy general name' ),
		'singular_name'     => _x( 'Portfolio Category', 'taxonomy singular name' ),
		'search_items'      => __( 'Search Portfolio Categories' ),
		'all_items'         => __( 'All Portfolio Categories' ),
		'parent_item'       => __( 'Parent Portfolio Category' ),
		'parent_item_colon' => __( 'Parent Portfolio Category:' ),
		'edit_item'         => __( 'Edit Portfolio Category' ), 
		'update_item'       => __( 'Update Portfolio Category' ),
		'add_new_item'      => __( 'Add New Portfolio Category' ),
		'new_item_name'     => __( 'New Portfolio Category' ),
		'menu_name'         => __( 'Portfolio Categories' ),
	);
	$args = array(
		'labels' => $labels,
		'hierarchical' => true,
	);
	register_taxonomy( 'portfolio_category', 'portfolio', $args );
}
add_action( 'init', 'beuh_taxonomies_portfolio', 0 );
