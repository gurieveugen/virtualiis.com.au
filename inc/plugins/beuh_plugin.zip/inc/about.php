<?php
// Registers the new post type 

function wpt_about_posttype() {
	register_post_type( 'about-us',
		array(
			'labels' => array(
				'name' => __( 'About Us', 'beuh_plg' ),
				'singular_name' => __( 'About Us' , 'beuh_plg'),
				'add_new' => __( 'Add New About Us', 'beuh_plg' ),
				'add_new_item' => __( 'Add New About Us', 'beuh_plg' ),
				'edit_item' => __( 'Edit About Us', 'beuh_plg' ),
				'new_item' => __( 'Add New About Us', 'beuh_plg' ),
				'view_item' => __( 'View About Us', 'beuh_plg' ),
				'search_items' => __( 'Search About Us', 'beuh_plg' ),
				'not_found' => __( 'No about us found', 'beuh_plg' ),
				'not_found_in_trash' => __( 'No about us found in trash', 'beuh_plg' )
			),
			'public' => true,
			'supports' => array( 'title', 'editor', 'thumbnail','excerpt'),
			'capability_type' => 'post',
			'rewrite' => array("slug" => "about-us"), // Permalinks format
			'menu_position' => 5,
			'exclude_from_search' => true 
		)
	);

}

add_action( 'init', 'wpt_about_posttype' );


