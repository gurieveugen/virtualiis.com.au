<?php
/**
 * Initialize the Team Post Meta Boxes. 
 */
add_action( 'admin_init', 'team_mb' );
function team_mb() {
  
  /**
   * Create a custom meta boxes array that we pass to 
   * the OptionTree Meta Box API Class.
   */
  $teamp_mb = array(
    'id'          => 'team_meta_box',
    'title'       => __( 'Team Post Setting', 'beuh_plg' ),
    'desc'        => '',
    'pages'       => array( 'team-post' ),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(
	  array(
        'label'       => __( 'Team Detail', 'beuh_plg' ),
        'id'          => 'gs_team',
        'type'        => 'tab'
      ),
      array(
        'label'       => __( 'Position', 'beuh_plg' ),
        'id'          => 'tp_post',
        'type'        => 'text',
        'desc'        => __( 'Input team position here.', 'beuh_plg' )
      ),
	  array(
        'label'       => __( 'Team Social Icon', 'beuh_plg' ),
        'id'          => 'tp_social-icon',
        'type'        => 'tab'
      ),
	   array(
        'label'       => __( 'Facebook link', 'beuh_plg' ),
        'id'          => 'fb_si',
        'type'        => 'text',
        'desc'        => __( 'Input link for Facebook', 'beuh_plg' )
      ),
	  array(
        'label'       => __( 'Twitter link', 'beuh_plg' ),
        'id'          => 'twit_si',
        'type'        => 'text',
        'desc'        => __( 'Input link for Twitter', 'beuh_plg' )
      ),
	  array(
        'label'       => __( 'Pinterest link', 'beuh_plg' ),
        'id'          => 'pinterest_si',
        'type'        => 'text',
        'desc'        => __( 'Input link for Pintereset', 'beuh_plg' )
      ),
	  array(
        'label'       => __( 'Google Plus link', 'beuh_plg' ),
        'id'          => 'gp_si',
        'type'        => 'text',
        'desc'        => __( 'Input link for Google Plus', 'beuh_plg' )
      ),
	  array(
        'label'       => __( 'Instagram link', 'beuh_plg' ),
        'id'          => 'instagram_si',
        'type'        => 'text',
        'desc'        => __( 'Input link for Instagram', 'beuh_plg' )
      ),
	  array(
        'label'       => __( 'Xing link', 'beuh_plg' ),
        'id'          => 'xing_si',
        'type'        => 'text',
        'desc'        => __( 'Input link for Xing', 'beuh_plg' )
      ),
	  array(
        'label'       => __( 'Another Social icon list', 'beuh_plg' ),
        'id'          => 'another_si',
        'type'        => 'list-item',
        'desc'        => __( 'Create another social icon list here.', 'beuh_plg' ),
		'settings'    => array( 
          array(
            'id'          => 'si_icon',
            'label'       => __( 'Social Icon', 'xovlox' ),
            'desc'        => __( 'Input your social icon here. <br/> You can check <a href="http://fontawesome.io/icons/" target="_blank">Here</a> for icon list. eg. fa-github', 'beuh_plg' ),
            'type'        => 'text',
          ),
		  array(
            'id'          => 'si_icon_link',
            'label'       => __( 'Social Icon Link', 'xovlox' ),
            'desc'        => __( 'Input your social icon link here.', 'beuh_plg' ),
            'type'        => 'text',
          ),
		)
      ),
	  array(
        'label'       => __( 'Email link', 'beuh_plg' ),
        'id'          => 'email_si',
        'type'        => 'text',
        'desc'        => __( 'Input email here(email address only,without mailto:)', 'beuh_plg' )
      ),
    )
  );
  
  /**
   * Register our meta boxes using the 
   * ot_register_meta_box() function.
   */
  if ( function_exists( 'ot_register_meta_box' ) )
    ot_register_meta_box( $teamp_mb );

}