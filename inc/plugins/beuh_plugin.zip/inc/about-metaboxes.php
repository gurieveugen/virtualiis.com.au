<?php
/**
 * Initialize the About Post Meta Boxes. 
 */
add_action( 'admin_init', 'about_mb' );
function about_mb() {
  
  /**
   * Create a custom meta boxes array that we pass to 
   * the OptionTree Meta Box API Class.
   */
  $about_mb = array(
    'id'          => 'about_meta_box',
    'title'       => __( 'Post Setting', 'beuh_plg' ),
    'desc'        => '',
    'pages'       => array( 'about-us' ),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(

      array(
        'label'       => __( 'Subtitle', 'beuh_plg' ),
        'id'          => 'about_post_title',
        'type'        => 'text',
        'desc'        => __( 'Input your subtitle/small title here(text below the about post title). eg. About Us', 'beuh_plg' )
      )
    )
  );
  
  /**
   * Register our meta boxes using the 
   * ot_register_meta_box() function.
   */
  if ( function_exists( 'ot_register_meta_box' ) )
    ot_register_meta_box( $about_mb );

}